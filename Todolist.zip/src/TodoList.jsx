import { useState } from "react";
import TodoTable from "./TodoTable";


function TodoList() {

const [desc,setDesc] = useState("");
const [todos, setTodos] = useState ([]);
const [date, setDate] = useState ("");
const handleChange = (event) => {
    setDesc(event.target.value);
};
  
const handleChange2 = (event) => {
    setDate(event.target.value);
};

const addTodo = () => {
    setTodos([...todos, {date, desc}]);
    setDate("");
    setDesc("");

};

    return(
        <>
            <input placeholder = "Date" onChange = {handleChange2} value = {date} />
            <input placeholder = "Description" onChange = {handleChange} value = {desc} />
            <button onClick = {addTodo}>Add</button>
            <TodoTable todos={todos} />
        </>
    );
}

export default TodoList;